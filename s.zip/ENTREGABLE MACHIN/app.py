import hmac
import os
from functools import wraps
from pathlib import Path

from flask import Flask, render_template, request, redirect, url_for, jsonify, session
import joblib
import pandas as pd
from dotenv import load_dotenv

from database import (
    init_db,
    insertar_tramite,
    insertar_notificacion,
    obtener_tramite,
    listar_tramites,
    actualizar_estado_tramite,
    listar_notificaciones,
    obtener_stats,
    reporte_por_area,
)

load_dotenv()

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "cambia-esta-clave-en-produccion")
init_db()

ADMIN_EMAIL = os.environ.get("ADMIN_EMAIL", "admin@novasalud.com")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "admin123")

MODEL_PATH = Path("model/modelo_prioridad.pkl")

def cargar_modelo():
    if not MODEL_PATH.exists():
        raise FileNotFoundError("Primero ejecuta: python train_model.py")
    return joblib.load(MODEL_PATH)

modelo = cargar_modelo()

def login_required(view):
    @wraps(view)
    def wrapped_view(*args, **kwargs):
        if not session.get("user_email"):
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped_view

def predecir_prioridad(tipo_tramite, area, dias_espera, urgencia, documentos_observados):
    entrada = pd.DataFrame([{
        "tipo_tramite": tipo_tramite,
        "area": area,
        "dias_espera": int(dias_espera),
        "urgencia": int(urgencia),
        "documentos_observados": int(documentos_observados)
    }])
    return modelo.predict(entrada)[0]

@app.route("/login", methods=["GET", "POST"])
def login():
    error = ""

    if request.method == "POST":
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")

        if not email or not password:
            error = "Completa todos los campos"
        elif (
            hmac.compare_digest(email.lower(), ADMIN_EMAIL.lower())
            and hmac.compare_digest(password, ADMIN_PASSWORD)
        ):
            session.clear()
            session["user_email"] = email
            return redirect(request.args.get("next") or url_for("index"))
        else:
            error = "Correo o contraseña incorrectos"

    return render_template("login.html", error=error)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/")
@login_required
def index():
    return render_template("index.html")

@app.route("/registrar", methods=["GET", "POST"])
@login_required
def registrar():
    if request.method == "POST":
        ciudadano = request.form["ciudadano"]
        dni = request.form["dni"]
        correo = request.form["correo"]
        tipo_tramite = request.form["tipo_tramite"]
        area = request.form["area"]
        descripcion = request.form["descripcion"]
        dias_espera = request.form["dias_espera"]
        urgencia = request.form["urgencia"]
        documentos_observados = request.form["documentos_observados"]

        prioridad = predecir_prioridad(
            tipo_tramite, area, dias_espera, urgencia, documentos_observados
        )

        tramite = insertar_tramite({
            "ciudadano": ciudadano,
            "dni": dni,
            "correo": correo,
            "tipo_tramite": tipo_tramite,
            "area": area,
            "descripcion": descripcion,
            "dias_espera": int(dias_espera),
            "urgencia": int(urgencia),
            "documentos_observados": int(documentos_observados),
            "prioridad": prioridad,
            "estado": "Recibido"
        })

        tramite_id = tramite["id"]

        insertar_notificacion(
            tramite_id,
            f"Su trámite fue registrado correctamente. Prioridad asignada: {prioridad.upper()}."
        )

        return redirect(url_for("resultado", tramite_id=tramite_id))

    return render_template("registrar.html")

@app.route("/resultado/<int:tramite_id>")
@login_required
def resultado(tramite_id):
    tramite = obtener_tramite(tramite_id)
    return render_template("resultado.html", tramite=tramite)

@app.route("/admin")
@login_required
def admin():
    filtro = request.args.get("prioridad", "")
    tramites = listar_tramites(filtro if filtro else None)
    stats = obtener_stats()
    return render_template("admin.html", tramites=tramites, stats=stats, filtro=filtro)

@app.route("/actualizar_estado/<int:tramite_id>", methods=["POST"])
@login_required
def actualizar_estado(tramite_id):
    nuevo_estado = request.form["estado"]

    actualizar_estado_tramite(tramite_id, nuevo_estado)

    insertar_notificacion(
        tramite_id,
        f"El estado de su trámite cambió a: {nuevo_estado}."
    )

    return redirect(url_for("admin"))

@app.route("/notificaciones/<int:tramite_id>")
@login_required
def notificaciones(tramite_id):
    tramite = obtener_tramite(tramite_id)
    notis = listar_notificaciones(tramite_id)
    return render_template("notificaciones.html", tramite=tramite, notis=notis)

@app.route("/api/reportes")
@login_required
def api_reportes():
    return jsonify(reporte_por_area())

if __name__ == "__main__":
    app.run(debug=True)
